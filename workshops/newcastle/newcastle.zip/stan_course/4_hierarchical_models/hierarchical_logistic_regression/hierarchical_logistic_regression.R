library(rstan)

setwd('')

############################################################
#    Explore input data
############################################################

input_data <- read_rdump('hierarchical_logistic_regression.data')

names(input_data)

input_data$n_income

input_data$income

############################################################
#    A simple logistic regression
############################################################

fit <- stan(file='logistic_regression.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

# Aggregate fit looks okay, but...
hist(params$p_ppc, main="", xlab="p_ppc")
abline(v=sum(input_data$y) / input_data$n_individuals,col=2,lty=1)

# Individual groups are very different from aggregrate response
hist(params$p_ppc, main="", xlab="p_age_ppc", breaks=0.01*(0:100)+0.0)
abline(v=sum(input_data$y * (input_data$age == 1)) / sum(input_data$age == 1), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$age == 2)) / sum(input_data$age == 2), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$age == 3)) / sum(input_data$age == 3), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$age == 4)) / sum(input_data$age == 4), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$age == 5)) / sum(input_data$age == 5), col=2, lty=1)

hist(params$p_ppc, main="", xlab="p_income_ppc", breaks=0.01*(0:100)+0.0)
abline(v=sum(input_data$y * (input_data$income == 1)) / sum(input_data$income == 1), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$income == 2)) / sum(input_data$income == 2), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$income == 3)) / sum(input_data$income == 3), col=2, lty=1)
abline(v=sum(input_data$y * (input_data$income == 4)) / sum(input_data$income == 4), col=2, lty=1)

############################################################
#    One-level, centered parameterization
############################################################

# Divergences!
fit <- stan(file='one_level_cp.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("sigma_beta"), inc_warmup=FALSE) # Getting stuck!
print(fit)

params = extract(fit)

attach(mtcars)
par(mfrow=c(2, 2))

hist(params$p_income_ppc[,1], main="Income = 1", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 1)) / sum(input_data$income == 1), col=2, lty=1)

hist(params$p_income_ppc[,2], main="Income = 2", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 2)) / sum(input_data$income == 2), col=2, lty=1)

hist(params$p_income_ppc[,3], main="Income = 3", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 3)) / sum(input_data$income == 3), col=2, lty=1)

hist(params$p_income_ppc[,4], main="Income = 4", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 4)) / sum(input_data$income == 4), col=2, lty=1)

############################################################
#    One-level, non-centered parameterization
############################################################

# No more divergences!
fit <- stan(file='one_level_ncp.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

print(fit)
hist_treedepth(fit)

params = extract(fit)

attach(mtcars)
par(mfrow=c(2, 2))

hist(params$p_income_ppc[,1], main="Income = 1", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 1)) / sum(input_data$income == 1), col=2, lty=1)

hist(params$p_income_ppc[,2], main="Income = 2", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 2)) / sum(input_data$income == 2), col=2, lty=1)

hist(params$p_income_ppc[,3], main="Income = 3", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 3)) / sum(input_data$income == 3), col=2, lty=1)

hist(params$p_income_ppc[,4], main="Income = 4", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 4)) / sum(input_data$income == 4), col=2, lty=1)

############################################################
#    Two-level, centered parameterization
############################################################

# Watch those divergences!
fit <- stan(file='two_level_cp.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

############################################################
#    Two-level, non-centered parameterization
############################################################

# No more divergences!
fit <- stan(file='two_level_ncp.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

attach(mtcars)
par(mfrow=c(3, 2))

hist(params$p_age_ppc[,1], main="Age = 1", xlab="p_age_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$age == 1)) / sum(input_data$age == 1), col=2, lty=1)

hist(params$p_age_ppc[,2], main="Age = 2", xlab="p_age_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$age == 2)) / sum(input_data$age == 2), col=2, lty=1)

hist(params$p_age_ppc[,3], main="Age = 3", xlab="p_age_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$age == 3)) / sum(input_data$age == 3), col=2, lty=1)

hist(params$p_age_ppc[,4], main="Age = 4", xlab="p_age_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$age == 4)) / sum(input_data$age == 4), col=2, lty=1)

hist(params$p_age_ppc[,5], main="Age = 5", xlab="p_age_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$age == 5)) / sum(input_data$age == 5), col=2, lty=1)

attach(mtcars)
par(mfrow=c(2, 2))

hist(params$p_income_ppc[,1], main="Income = 1", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 1)) / sum(input_data$income == 1), col=2, lty=1)

hist(params$p_income_ppc[,2], main="Income = 2", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 2)) / sum(input_data$income == 2), col=2, lty=1)

hist(params$p_income_ppc[,3], main="Income = 3", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 3)) / sum(input_data$income == 3), col=2, lty=1)

hist(params$p_income_ppc[,4], main="Income = 4", xlab="p_income_ppc", breaks=0.025*(0:40))
abline(v=sum(input_data$y * (input_data$income == 4)) / sum(input_data$income == 4), col=2, lty=1)
