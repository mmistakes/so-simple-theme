library(rstan)

setwd('')

input_data <- read_rdump('outbreak.stan.data')

# Watch for divergences!
fit <- stan(file='sir.stan', data=input_data,
                  iter=2000, chains=1, seed=194838, refresh=100,
                  control=list(stepsize=0.001) )

traceplot(fit)
print(fit)

params = extract(fit)

# Marginal parameter posteriors
attach(mtcars)
par(mfrow=c(3, 2))

hist(params$beta, main="", xlab="beta (1 /days)")
abline(v=1, col=2, lty=1)

hist(params$gamma, main="", xlab="gamma (1 /days)")
abline(v=0.2, col=2, lty=1)

hist(params$xi, main="", xlab="xi ( cells / (mL * days * persons) )")
abline(v=10, col=2, lty=1)

hist(params$delta, main="", xlab="delta (1 / days)")
abline(v=0.333, col=2, lty=1)

hist(params$R0, main="", xlab="R0")
abline(v=1.5, col=2, lty=1)

# Cholera Concentration Fit
cred <- sapply(1:length(input_data$t), function(x) quantile(params$y[,x,4], probs = c(0.05, 0.5, 0.95)))
plot(input_data$t, input_data$B_hat, xlab="t (days)",
     ylab="Cholera Concentration (cells / mL)", col=1, pch=16, cex=0.8)
lines(input_data$t, cred[1,], col="gray60")
lines(input_data$t, cred[2,], col="gray60")
lines(input_data$t, cred[3,], col="gray60")

# Cholera Concentration PPC
cred <- sapply(1:length(input_data$t), function(x) quantile(params$B_ppc[,x], probs = c(0.05, 0.5, 0.95)))
plot(input_data$t, input_data$B_hat, xlab="t (days)",
     ylab="Cholera Concentration (cells / mL)", col=1, pch=16, cex=0.8)
lines(input_data$t, cred[1,], col="gray60")
lines(input_data$t, cred[2,], col="gray60")
lines(input_data$t, cred[3,], col="gray60")

# SIR
true_evolution <- read.table("truth.data")

s_cred <- sapply(1:length(input_data$t), function(x) quantile(params$y[,x,1], probs = c(0.05, 0.5, 0.95)))
i_cred <- sapply(1:length(input_data$t), function(x) quantile(params$y[,x,2], probs = c(0.05, 0.5, 0.95)))
r_cred <- sapply(1:length(input_data$t), function(x) quantile(params$y[,x,3], probs = c(0.05, 0.5, 0.95)))

plot(input_data$t, s_cred[2,], col="black", type="l",
     xlab="t (days)", ylab="Population", ylim=c(0, 10000))

polygon(c(input_data$t, rev(input_data$t)), c(s_cred[1,], rev(s_cred[3,])),
        col = "orchid1", border = NA)
lines(input_data$t, s_cred[2,], col="orchid4")
lines(true_evolution$V1, true_evolution$V2, col="green")

polygon(c(input_data$t, rev(input_data$t)), c(i_cred[1,], rev(i_cred[3,])),
        col = "orchid1", border = NA)
lines(input_data$t, i_cred[2,], col="orchid4")
lines(true_evolution$V1, true_evolution$V3, col="green")

polygon(c(input_data$t, rev(input_data$t)), c(r_cred[1,], rev(r_cred[3,])),
        col = "orchid1", border = NA)
lines(input_data$t, r_cred[2,], col="orchid4")
lines(true_evolution$V1, true_evolution$V4, col="green")
