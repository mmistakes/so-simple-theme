library(rstan)

setwd('')

input_data <- read_rdump('irt-data.R')

# IRT 1PL - improper priors
# Divergences!
fit <- stan(file='irt_improper.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("b[15]", "theta[10]", "theta[75]")) # Improper posterior
print(fit) # No convergence

# IRT 1PL - vague priors for both theta and b
# So many divergences
fit <- stan(file='irt_vague.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("b[15]", "theta[10]", "theta[75]"))
print(fit) # No convergence

# IRT 1PL - strong prior for theta, improper prior for b
# Watch out for divergences
fit <- stan(file='irt_improper_b.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("b[15]", "theta[10]", "theta[75]"))
print(fit)

params = extract(fit)

attach(mtcars)
par(mfrow=c(2, 2))

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,9]) / length(params$y_tilde[x,,9]))
hist(probs, main="Student 9", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,9]) / length(input_data$y[,9]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,33]) / length(params$y_tilde[x,,33]))
hist(probs, main="Student 33", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,33]) / length(input_data$y[,33]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,50]) / length(params$y_tilde[x,,50]))
hist(probs, main="Student 50", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,50]) / length(input_data$y[,50]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,90]) / length(params$y_tilde[x,,90]))
hist(probs, main="Student 90", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,90]) / length(input_data$y[,90]), col=2, lty=1)

# IRT 1PL - hierarchical prior, non-identified means!
fit <- stan(file='irt_hier_overparam.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("b[15]", "theta[10]", "theta[75]")) # Very slow mixing
print(fit)

# IRT 1PL - hierarchical prior, single mean
fit <- stan(file='irt_hier.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("b[15]", "theta[10]", "theta[75]"))
print(fit)

params = extract(fit)

attach(mtcars)
par(mfrow=c(2, 2))

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,9]) / length(params$y_tilde[x,,9]))
hist(probs, main="Student 9", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,9]) / length(input_data$y[,9]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,33]) / length(params$y_tilde[x,,33]))
hist(probs, main="Student 33", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,33]) / length(input_data$y[,33]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,50]) / length(params$y_tilde[x,,50]))
hist(probs, main="Student 50", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,50]) / length(input_data$y[,50]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,90]) / length(params$y_tilde[x,,90]))
hist(probs, main="Student 90", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,90]) / length(input_data$y[,90]), col=2, lty=1)

z_tilde <- sapply(1:input_data$I, function(x) sum(params$y_tilde[,x,]) / length(params$y_tilde[,x,]))
z <- sapply(1:input_data$I, function(x) sum(input_data$y[x,]) / length(input_data$y[x,]))

p1 <- hist(z, breaks=0.1*(0:10))
p2 <- hist(z_tilde, breaks=0.1*(0:10))
plot(p1, col=rgb(0, 0, 1, 0.25), main="Question Difficulties", xlab="Prob Correct")
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

# IRT 2PL - improper priors
# So many divergences
fit <- stan(file='irt_2pl_improper.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("a[8]", "a[9]", "b[5]", "b[6]", "theta[10]", "theta[75]"))
print(fit) # No convergence

# IRT 2PL - proper hierarchical priors but sign non-identifiability
# A few divergences
fit <- stan(file='irt_2pl_hier_unconstrained.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("a[8]", "a[9]", "b[5]", "b[6]", "theta[10]", "theta[75]"))
print(fit) # No convergence

# IRT 2PL - proper hierarchical priors with identifying constraints
fit <- stan(file='irt_2pl_hier.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit, pars=c("a[8]", "a[9]", "b[5]", "b[6]", "theta[10]", "theta[75]"))
print(fit) # Hyperparameters mixing slowly, motivates non-centered parameterization

params = extract(fit)

attach(mtcars)
par(mfrow=c(2, 2))

probs <- sapply(1:input_data$I, function(x) sum(params$y_tilde[x]))

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,9]) / length(params$y_tilde[x,,9]))
hist(probs, main="Student 9", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,9]) / length(input_data$y[,9]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,33]) / length(params$y_tilde[x,,33]))
hist(probs, main="Student 33", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,33]) / length(input_data$y[,33]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,50]) / length(params$y_tilde[x,,50]))
hist(probs, main="Student 50", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,50]) / length(input_data$y[,50]), col=2, lty=1)

probs <- sapply(1:1000, function(x) sum(params$y_tilde[x,,90]) / length(params$y_tilde[x,,90]))
hist(probs, main="Student 90", xlab="Prob Correct", breaks=0.05*(0:20))
abline(v=sum(input_data$y[,90]) / length(input_data$y[,90]), col=2, lty=1)

z_tilde <- sapply(1:input_data$I, function(x) sum(params$y_tilde[,x,]) / length(params$y_tilde[,x,]))
z <- sapply(1:input_data$I, function(x) sum(input_data$y[x,]) / length(input_data$y[x,]))

p1 <- hist(z, breaks=0.1*(0:10))
p2 <- hist(z_tilde, breaks=0.1*(0:10))
plot(p1, col=rgb(0, 0, 1, 0.25), main="Question Difficulties", xlab="Prob Correct")
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)
