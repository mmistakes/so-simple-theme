library(rstan)

setwd('')

# Generate data
T <- 200;
sigma1 <- 0.5;

fit <- stan(file='generate_autoregressive.stan', iter=1, data=c("T", "sigma1"),
            chains=1, seed=194838, algorithm="Fixed_param")
y <- extract(fit)$y[1,]

plot(1:T, y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)

stan_rdump(c("T", "y", "sigma1"), file="autoregressive.data")

# Student input begins here
input_data <- read_rdump('autoregressive.data')

fit <- stan(file='arch1.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

cred <- sapply(1:input_data$T, function(x) quantile(params$y_ppc[,x], probs = c(0.05, 0.5, 0.95)))
plot(1:input_data$T, input_data$y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)
lines(1:input_data$T, cred[1,], col="gray60")
lines(1:input_data$T, cred[2,], col="gray60")
lines(1:input_data$T, cred[3,], col="gray60")

fit <- stan(file='garch1_1.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

cred <- sapply(1:T, function(x) quantile(params$y_ppc[,x], probs = c(0.05, 0.5, 0.95)))
plot(1:input_data$T, input_data$y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)
lines(1:input_data$T, cred[1,], col="gray60")
lines(1:input_data$T, cred[2,], col="gray60")
lines(1:input_data$T, cred[3,], col="gray60")