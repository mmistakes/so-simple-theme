library(rstan)

setwd('')

# Generate data
T <- 200;
sigma <- 0.1;
omega <- 2.0 * pi / T;
phi <- 0.33 * pi;

y <- rep(NA, T);
y[1] <- rnorm(1, sin(omega * 0 + phi) * sin(5.0 * omega * 0 + phi), sigma);
for (t in 2:T)
  y[t] <- rnorm(1, sin(omega * t + phi) * sin(5.0 * omega * t + phi), sigma);

plot(1:T, y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)

stan_rdump(c("T", "y"), file="autoregressive.data")

# Student input begins here
input_data <- read_rdump('autoregressive.data')
input_data <- c(input_data, K=5)

fit <- stan(file='arK.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

cred <- sapply(1:input_data$T, function(x) quantile(params$y_ppc[,x],
               probs = c(0.05, 0.5, 0.95)))
plot(1:input_data$T, input_data$y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)
lines(1:input_data$T, cred[1,], col="gray60")
lines(1:input_data$T, cred[2,], col="gray60")
lines(1:input_data$T, cred[3,], col="gray60")

# Try with a small autocorrelation time
input_data <- read_rdump('autoregressive.data')
input_data <- c(input_data, K=1)

fit <- stan(file='arK.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

params = extract(fit)

cred <- sapply(1:input_data$T, function(x) quantile(params$y_ppc[,x],
               probs = c(0.05, 0.5, 0.95)))
plot(1:input_data$T, input_data$y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)
lines(1:input_data$T, cred[1,], col="gray60")
lines(1:input_data$T, cred[2,], col="gray60")
lines(1:input_data$T, cred[3,], col="gray60")

# Try with a large autocorrelation time
input_data <- read_rdump('autoregressive.data')
input_data <- c(input_data, K=10)

fit <- stan(file='arK.stan', data=input_data,
iter=2000, chains=1, seed=4938483)

params = extract(fit)

cred <- sapply(1:input_data$T, function(x) quantile(params$y_ppc[,x],
               probs = c(0.05, 0.5, 0.95)))
plot(1:input_data$T, input_data$y, xlab="t", ylab="y", col=1, pch=16, cex=0.8)
lines(1:input_data$T, cred[1,], col="gray60")
lines(1:input_data$T, cred[2,], col="gray60")
lines(1:input_data$T, cred[3,], col="gray60")