library(rstan)

setwd('')

input_data <- read_rdump('simple_gp.data')

fit <- stan(file='simple_gp.stan', data=input_data,
            iter=2000, chains=1, seed=4938483, init=0.5)

traceplot(fit)
print(fit)

params = extract(fit)

plot(input_data$x, input_data$y, xlab="x", ylab="y", col=1, pch=16, cex=0.8)
lines(params$x_ppc[1,], params$y_ppc[1,], col="black")
lines(params$x_ppc[10,], params$y_ppc[10,], col="black")
lines(params$x_ppc[100,], params$y_ppc[100,], col="black")
lines(params$x_ppc[500,], params$y_ppc[500,], col="black")