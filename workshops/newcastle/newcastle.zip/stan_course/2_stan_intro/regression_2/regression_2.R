library(rstan)

setwd('')

input_data <- read_rdump('regression.data')

# Looks like a crazy high-dimensional polynomial!
plot(input_data$x, input_data$y, xlab="x", ylab="y", col=2, pch=16, cex=0.8)

# The covariates looks pretty uniformly distributed...
hist(input_data$x)

# Fit a third-order polynomial regression
fit <- stan(file='3rd_order.stan', data=input_data,
            iter=2000, chains=1, seed=4938483)

traceplot(fit)
print(fit)

params = extract(fit)

plot(params$x_ppc, params$y_ppc, xlab="x", ylab="y", col=2, pch=16, cex=0.8)
points(input_data$x, input_data$y, col=4, pch=16, cex=0.8)