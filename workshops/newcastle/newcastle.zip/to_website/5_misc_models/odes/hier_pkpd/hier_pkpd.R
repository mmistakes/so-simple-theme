library(rstan)

setwd('')

############################################################
# Generate data
############################################################

t <- c(0.1, 0.180164823065, 0.324593634702, 0.584803547643, 1.05361027689,
       1.89823509116, 3.41995189335, 6.16155027758, 11.1009461557, 20.0)
config_data <- list(N_patients = 10, N_t = 10,
                    t = t, t0 = 0, C0 = array(c(0), dim=1), D = 15, T = 5)

fit <- stan(file='generate_data.stan', data=config_data, iter=1,
            chains=1, seed=194838, algorithm="Fixed_param")

C_hat <- extract(fit)$C_hat[1,,]
Cl_max <- extract(fit)$Cl_max[1,]
V <- extract(fit)$V[1,]

N_patients <- config_data$N_patients
N_t <- config_data$N_t
t <- config_data$t
t0 <- config_data$t0
C0 <- config_data$C0
D <- config_data$D
T <- config_data$T
stan_rdump(c("N_patients", "N_t", "t", "t0", "C0", "D", "T",
             "C_hat", "Cl_max", "V"),
           file="hier_pkpd.data")

############################################################
# Student input begins here
############################################################

input_data <- read_rdump('hier_pkpd.data')

fit <- stan(file='hier_pkpd.stan', data=input_data,
                  iter=2000, chains=1, seed=194838, refresh=100,
                  control=list(stepsize=0.001) )

traceplot(fit)
print(fit)

params = extract(fit)

# Global parameter posteriors
attach(mtcars)
par(mfrow=c(3, 2))

hist(params$mu_V, main="", xlab="mu_V (L)")
abline(v=log(5), col=2, lty=1)

hist(params$sigma_V, main="", xlab="sigma_V (L)")
abline(v=sqrt(0.09), col=2, lty=1)

hist(params$mu_Cl_max, main="", xlab="mu_Cl_max (mg/day)")
abline(v=log(1), col=2, lty=1)

hist(params$sigma_Cl_max, main="", xlab="sigma_Cl_max (mg/day)")
abline(v=sqrt(0.04), col=2, lty=1)

hist(params$C50, main="", xlab="C50")
abline(v=0.5, col=2, lty=1)

# Patient 3 posteriors
attach(mtcars)
par(mfrow=c(1, 2))

hist(params$V[,3], main="Patient 3", xlab="V (L)")
abline(v=input_data$V[3], col=2, lty=1)

hist(params$Cl_max[,3], main="Patient 3", xlab="Cl_max (mg/day)")
abline(v=input_data$Cl_max[3], col=2, lty=1)

cred <- sapply(1:length(input_data$t), function(x) quantile(params$C[,3,x], probs = c(0.05, 0.5, 0.95)))
plot(input_data$t, input_data$C_hat[3,], xlab="t (days)",
     ylab="Concentration (mg/L)", log="x", ylim=c(0, 4), col=1, pch=16, cex=0.8)
polygon(c(input_data$t, rev(input_data$t)), c(cred[1,], rev(cred[3,])),
        col = "orchid1", border = NA)
lines(input_data$t, cred[2,], col="orchid4")
points(input_data$t, input_data$C_hat[3,], col=1, pch=16, cex=0.8)

cred <- sapply(1:length(input_data$t), function(x) quantile(params$C_ppc[,3,x], probs = c(0.05, 0.5, 0.95)))
plot(input_data$t, input_data$C_hat[3,], xlab="t (days)",
     ylab="Concentration (mg/L)", log="x", ylim=c(0, 4), col=1, pch=16, cex=0.8)
polygon(c(input_data$t, rev(input_data$t)), c(cred[1,], rev(cred[3,])),
        col = "orchid1", border = NA)
lines(input_data$t, cred[2,], col="orchid4")
points(input_data$t, input_data$C_hat[3,], col=1, pch=16, cex=0.8)
