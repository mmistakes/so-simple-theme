library(rstan)

setwd('')

# Create data
fit <- stan(file='generate_data.stan', iter=1,
            chains=1, seed=194838, algorithm="Fixed_param")

data <- list(n_data = 25, n_covariates=3,
             X=extract(fit)$X[1,,], y=extract(fit)$y[1,])

# Fit data using naive implementation
fit <- stan(file='naive.stan', data=data,
            iter=2000, chains=1, seed=4938483)

params = extract(fit)

attach(mtcars)
par(mfrow=c(3, 2))

hist(params$sigma, main="", xlab="sigma")
abline(v=1,col=2,lty=1)

hist(params$alpha, main="", xlab="alpha")
abline(v=10,col=2,lty=1)

hist(params$beta[,1], main="", xlab="beta[1]")
abline(v=5,col=2,lty=1)

hist(params$beta[,2], main="", xlab="beta[2]")
abline(v=-3,col=2,lty=1)

hist(params$beta[,3], main="", xlab="beta[3]")
abline(v=2,col=2,lty=1)