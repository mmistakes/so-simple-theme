setwd("~/Stan/isba16/course")
library(rstan)
rstan_options(auto_write = TRUE)

options(mc.cores=4)

set.seed(234546)

colitis <- new.env()
source("colitis_data.R", colitis)
colitis <- as.list(colitis)

fit1 <- stan("hierarch_logistic_3.stan",
             data=c(colitis, list(pi_ex=rep(0.8, colitis$H))),
             control=list(adapt_delta=0.95),
             open_progress=FALSE
             )

pars <- c("theta", "mu", "tau", "post_p_ex", "lp__")

print(fit1, probs=c(0.025,0.5,0.975), pars=pars)

plot(fit1, pars=c("theta", "mu"))

traceplot(fit1, pars=c("theta", "mu", "tau", "lp__"))

traceplot(fit1, pars=c("theta", "mu", "lp__"))


## add an outlier with p=0.5

surprise <- with(colitis, list(n=c(n, 200), r=c(r, 100), H=H+1))
surprise


fit2 <- stan("hierarch_logistic_3.stan",
             data=c(surprise, list(pi_ex=rep(0.8, surprise$H))),
             control=list(adapt_delta=0.999),
             open_progress=FALSE
             )

print(fit2, probs=c(0.025,0.5,0.975), pars=pars)

plot(fit2, pars=c("theta", "theta_ex", "theta_nex", "mu"))

pairs(fit2, pars=c("mu", "theta[5]", "theta_ex[5]", "theta_nex[5]", "post_p_ex[5]"))

stan_diag(fit2, info = 'sample')

stan_ac(fit2, pars=c("theta", "post_p_ex", "mu", "tau", "lp__"))

