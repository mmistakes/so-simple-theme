## adapt to where you store these files
setwd("~/Stan/isba16/course")

## utilities
inv_logit <- function(l) 1/(1+exp(-l))
logit <- function(p) log(p/(1-p))

library(rstan)
rstan_options(auto_write = TRUE)

options(mc.cores=4)

colitis <- new.env()
source("colitis_data.R", colitis)
colitis <- as.list(colitis)

set.seed(234546)

fit0 <- stan("hierarch_logistic_0.stan",
             data=colitis,
             open_progress=FALSE
             )

fit1 <- stan("hierarch_logistic_1.stan",
             data=colitis,
             open_progress=FALSE
             )

fit2 <- stan("hierarch_logistic_1.stan",
             data=colitis,
             control=list(adapt_delta=0.99),
             open_progress=FALSE
             )

fit3 <- stan("hierarch_logistic_1_vec.stan",
             data=colitis,
             control=list(adapt_delta=0.99),
             open_progress=FALSE
             )

fit0
fit1
fit2
fit3

fit4_ncp <- stan("hierarch_logistic_2_ncp.stan",
                 data=colitis,
                 control=list(adapt_delta=0.995),
                 open_progress=FALSE
                 )

fit4_cp <- stan("hierarch_logistic_2_cp.stan",
                data=colitis,
                control=list(adapt_delta=0.9999),
                open_progress=FALSE
                )


print(fit4_ncp, probs=c(0.025,0.5,0.975))
print(fit4_cp , probs=c(0.025,0.5,0.975))

post <- extract(fit4_ncp)

names(post)
S <- length(post$theta_pred)
pars <- c("mu", "tau", "lp__")

## Simulation 1
## H=100 trials, n=10

H1 <- 100
n1 <- 10

draws1 <- sample.int(S, H1)

r_sim1 <- sapply(inv_logit(post$theta_pred[draws1]), rbinom, n=1, size=n1)
r_sim1


fit4_sim1_ncp <- stan("hierarch_logistic_2_ncp.stan",
                      data=list(H=H1, n=rep(n1, H1), r=r_sim1),
                      open_progress=FALSE
                      )

fit4_sim1_cp <- stan("hierarch_logistic_2_cp.stan",
                     data=list(H=H1, n=rep(n1, H1), r=r_sim1),
                     open_progress=FALSE
                     )

print(fit4_sim1_ncp, probs=c(0.025,0.5,0.975), pars=pars)
print(fit4_sim1_cp,  probs=c(0.025,0.5,0.975), pars=pars)


## Simulation 2
## H=10 trials, n=100

H2 <- 100
n2 <- 100

draws2 <- sample.int(S, H2)

r_sim2 <- sapply(inv_logit(post$theta_pred[draws2]), rbinom, n=1, size=n2)
r_sim2


fit4_sim2_ncp <- stan("hierarch_logistic_2_ncp.stan",
                      data=list(H=H2, n=rep(n2, H2), r=r_sim2),
                      open_progress=FALSE
                      )

fit4_sim2_cp <- stan("hierarch_logistic_2_cp.stan",
                     data=list(H=H2, n=rep(n2, H2), r=r_sim2),
                     open_progress=FALSE
                     )

print(fit4_sim2_ncp, probs=c(0.025,0.5,0.975), pars=pars)
print(fit4_sim2_cp,  probs=c(0.025,0.5,0.975), pars=pars)
