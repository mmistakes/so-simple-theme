## adapt to where you store these files
setwd("1~/Stan/isba16/course")

## utilities
inv_logit <- function(l) 1/(1+exp(-l))
logit <- function(p) log(p/(1-p))

library(rstan)
rstan_options(auto_write = TRUE)

options(mc.cores=4)

colitis_data <- new.env()
source("colitis_data.R", colitis_data)
colitis <- as.list(colitis_data)

set.seed(234546)

fit1 <- stan("logistic_base.stan",
             data=colitis
             )

fit1
