## adapt to where you store these files
setwd("~/Stan/isba16/course")

## utilities
inv_logit <- function(l) 1/(1+exp(-l))
logit <- function(p) log(p/(1-p))

library(rstan)
rstan_options(auto_write = TRUE)

options(mc.cores=4)

if(FALSE) {
    ## how to export data in a cmdstan compatible format
    colitis <- read.csv("colitis.csv")
    H <- nrow(colitis)
    stan_rdump(c("n", "r", "H"), "colitis_data.R", envir=list2env(colitis))
}

colitis_data <- new.env()
source("colitis_data.R", colitis_data)

set.seed(234546)

fit1 <- stan("logistic.stan",
             data=colitis_data,
             open_progress=FALSE
             )

fit1

## try out the data boundaries protections

fit_fail <- stan("logistic.stan",
                 data=list(H=4, r=c(-1,0,0,1), n=rep(10, 4)),
                 open_progress=FALSE
                 )

fit_fail <- stan("logistic.stan",
                 data=list(H=4, r=c(12,0,0,1), n=rep(10, 4)),
                 open_progress=FALSE
                 )

fit_fail <- stan("logistic.stan",
                 data=list(H=4, r=c(12,15,0,1), n=c(100, 10, 10, 10)),
                 open_progress=FALSE
                 )
