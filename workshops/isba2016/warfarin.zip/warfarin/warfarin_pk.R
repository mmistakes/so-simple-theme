library(rstan)
library(ggplot2)
theme_set(theme_bw())
rstan_options(auto_write = TRUE)

options(mc.cores=4)

set.seed(2432543)

## data has been prepared with the warfarin_munge.R script (includes
## setup of ragged array structures)
warf_data <- new.env()
source("warfarin_data.R", warf_data)
warf_data <- as.list(warf_data)

## look at data
pk_conc <- as.data.frame(warf_data[c("id", "time", "dv")])

qplot(time, dv, data=pk_conc, geom=c("point", "line"), alpha=I(0.5), group=id)

qplot(time, dv, data=subset(pk_conc, id < 10), geom=c("point", "line")) + facet_wrap(~id)


expose_stan_functions("warfarin_1cmt_ode.stan")

# now we have the functions defined in the Stan model available in R:
pk_1cmt_oral

run_stan_ode <- function(tad, dose, lka, lCL, lV) {
    res <- pk_1cmt_oral(tad, dose, lka, lCL, lV, array(dim=0))
    ## res is a list of 2-component vectors, join these for convenient
    ## processing
    do.call(rbind, res)
}

tad <- seq(0.1,32,length=101)
prior_sim <- run_stan_ode(tad, 10, log(log(2)/5), log(log(2)/1), log(1))

par(mfrow=c(1,2))
plot(tad, prior_sim[,1], type="l", xlab="Time after dose [h]", ylab="Amount dosing cmt [mg]", mgp=c(1.5,0.5,0))
plot(tad, prior_sim[,2], type="l", xlab="Time after dose [h]", ylab="Concentration central cmt [mg/l]", mgp=c(1.5,0.5,0))
par(mfrow=c(1,1))


## define initials
init <-function(){
  list(lCL=rnorm(1,log(0.1),log(1.2)/1.96),
       lV=rnorm(1,log(8),log(1.2)/1.96),
       lka=rnorm(1,log(1),log(1.2)/1.96),
       sigma_y=rlnorm(1,log(0.1),1),
       sigma_eta=rlnorm(2,log(0.3),1),
       LR_eta=diag(2),
       xi_eta=matrix(rep(0, 2*warf_data$J), nrow=2)
       )
}

set.seed(54667)

if (FALSE) {
    ## takes ~5min with upcoming 2.10...
    pk_fit_1cmt_ode <- stan("warfarin_1cmt_ode.stan"
                           ,data=warf_data,
                           ,chains=4
                           ,init=init
                           ,warmup=150
                           ,iter=250)

}

## ... better for this case: solve analytically (less flexibility)

## Frist cross check that analytical solution agrees with ODE solution
expose_stan_functions("warfarin_1cmt_analytic.stan")

## analytic solution calculates directly in log-space for numerical
## stability reasons
lpk <- pk_1cmt_oral_analytic(tad, log(10), log(log(2)/5), log(log(2)/1), log(1))

plot(tad, prior_sim[,2], type="l", xlab="Time after dose [h]", ylab="Concentration central cmt [mg/l]")
points(tad, exp(lpk), col="red")

## General remark: expose Stan functions and test with R facilities
## for correctness.

pk_fit_1cmt_analytic <- stan("warfarin_1cmt_analytic.stan"
                            ,data=warf_data
                            ,chains=4
                            ,init=init
                            ,warmup=250
                            ,iter=500
                            ,control=list(adapt_delta=0.95)
                            ,open_progress=FALSE)

pars <- c("lka", "lCL", "lV", "ka", "CL", "V", "rho", "sigma_eta", "sigma_y")

print(pk_fit_1cmt_analytic, pars=pars)

## extract samples
post_1cmt <- extract(pk_fit_1cmt_analytic)

## do some first basic checking; this often means to manage those
## arrays in an efficient manner
dim(post_1cmt$ires)

pk_conc$ires <- colMeans(post_1cmt$ires)
pk_conc$ipre <- colMeans(post_1cmt$mu)

qplot(time, ires, data=pk_conc) + geom_smooth(se=FALSE)

## it is recommended to check the pairs plot for possible problems
## like strong correlations between parameters which should hint
## towards better parametrizations
pairs(pk_fit_1cmt_analytic, pars=c("lka", "lCL", "lV", "lp__"))

## create a plot per patient
pdf("subjects.pdf", 10, 10)
qplot(time, dv, data=pk_conc, group=id, log="y", geom="point") + facet_wrap(~id) + geom_line(aes(y=exp(ipre)))
dev.off()


## Exercise 1: Remove outlier and refit. For this edit the munge script
## and execute again.
## Exercise 2: Try out the centered parametrization
