library(rstan)
library(plyr)

## see O’Reilly RA, Aggeler PM, Leong SL. Studies of the coumarin anticoagulant drugs: the pharmacodynamics of warfarin in man. Journal of Clinical Investigation, 1963; 42: 1542-1551.
## O’Reilly RA, Aggeler PM. Studies of the coumarin anticoagulant drugs: initiation of warfarin therapy without a loading dose. Circulation, 1968; 38:169-177.

raw <- read.table("warfarin_data_corrected.csv", header=TRUE, na.string=".", sep=";")

## we discard early pk measurements to get rid of the short time-lag
## which simplifies the model substantially. Selecting dvid==1 selects
## the measurements taken from blood samples (dvid==2 is for the
## pharmacodynamic response which is the effect of the drug
## concentration on the body, but we do not model this here).
pk_conc <- subset(raw, dvid==1 & !is.na(dv) & time > 2)

head(pk_conc)

## get the dosing information at t=0 for each patient
dose <- raw$amt[!is.na(raw$amt)]

## setup RAGGED ARRAY strucutres to loop over DV in Stan program
## rle = run length encoding
## counts the number of times a patients ID is repeated

## the dv and the time vector have the data we need for all patients
dv <- pk_conc$dv
time <- pk_conc$time
## the rle command is key here to match later in the Stan program data
## for a given subject to measurements
rag <- rle(pk_conc$id)
rag
## N now contains per patient the number of measurements
N <- rag$lengths
N

id <- pk_conc$id

## total number of patients
J <- length(N)

## sanity checks:
sum(N) == nrow(pk_conc)
length(dose) == J

## export data in cmdstan compatible format
stan_rdump(list("id", "dose", "dv", "time", "N", "J"), file="warfarin_data.R")

