############################################################
# Initial setup
############################################################

library(rstan)
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
source('stan_utility.R')

############################################################
# Fit ordinal model with non-identified intercept
############################################################

input_data <- read_rdump('ordinal_regression.data.R')
fit <- stan(file='ordinal_regression1.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit, pars=c("alpha", "beta", "c"))
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Plot marginal posteriors
par(mfrow=c(2, 4))

hist(params$alpha, main="", xlab="alpha")
abline(v=2,col=2,lty=1)

hist(params$beta[,1], main="", xlab="beta[1]")
abline(v=-1.5625,col=2,lty=1)

hist(params$beta[,2], main="", xlab="beta[2]")
abline(v=2.5,col=2,lty=1)

hist(params$beta[,3], main="", xlab="beta[3]")
abline(v=5.625,col=2,lty=1)

hist(params$c[,1], main="", xlab="c[1]")
abline(v=1,col=2,lty=1)

hist(params$c[,2], main="", xlab="c[2]")
abline(v=3,col=2,lty=1)

hist(params$c[,3], main="", xlab="c[3]")
abline(v=5,col=2,lty=1)

hist(params$c[,4], main="", xlab="c[4]")
abline(v=7,col=2,lty=1)

# Plot weakly-identified pairs
pairs(fit, pars=c("alpha", "c"))

# Plot (poor) aggregated predictive distribution
p1 <- hist(params$y_ppc, breaks=(0:5), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=(0:5), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

############################################################
# Fit ordinal model without non-identified intercept
############################################################

fit <- stan(file='ordinal_regression2.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit, pars=c("beta", "c"))
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Plot marginal posteriors
par(mfrow=c(2, 4))

hist(params$beta[,1], main="", xlab="beta[1]")
abline(v=-1.5625,col=2,lty=1)

hist(params$beta[,2], main="", xlab="beta[2]")
abline(v=2.5,col=2,lty=1)

hist(params$beta[,3], main="", xlab="beta[3]")
abline(v=5.625,col=2,lty=1)

hist(params$c[,1], main="", xlab="c[1]")
hist(params$c[,2], main="", xlab="c[2]")
hist(params$c[,3], main="", xlab="c[3]")
hist(params$c[,4], main="", xlab="c[4]")

# Plot aggregated predictive distribution
p1 <- hist(params$y_ppc, breaks=(0:5), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=(0:5), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)
