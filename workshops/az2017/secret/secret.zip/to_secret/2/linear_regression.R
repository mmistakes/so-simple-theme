############################################################
# Initial setup
############################################################

library(rstan)
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
source('stan_utility.R')

breaks <- function(mag, N) {
  return(mag*(2*(0:N)/N - 1))
}

############################################################
# Linear regression with no priors on the slopes
############################################################

input_data <- read_rdump("linear_regression.data.R")

beta_true <- input_data$beta_true
hist(beta_true, main="", xlab="True Slopes", breaks(11, 100))

fit <- stan(file='linear_regression1.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)
# Huge autocorrelations due to the non-identifiabilty

params = extract(fit)

# Extreme slopes due to non-identifiability
hist(sapply(1:M, function(m) mean(params$beta[,m])), main="",
     xlab="Inferred Slope Means", breaks=breaks(500, 25))

hist(sapply(1:M, function(m) mean(params$beta[,m]) / sd(params$beta[,m])),
     main="", xlab="Inferred Slope Coeff of Var", breaks=breaks(6, 25)

# Because of the huge uncertainties the overall errors don't look that poor
hist(sapply(1:M, function(m) (beta_true[m] - mean(params$beta[,m])) / sd(params$beta[,m])),
     main="", xlab="Relative Error", breaks=breaks(6, 25))

# Even the aggregated predictive distribution seems okay
y_ppc = params$y_ppc
dim(y_ppc) <- NULL

p1 <- hist(y_ppc, breaks=breaks(200, 25), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=breaks(200, 25), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

############################################################
# Linear regression with strongly regularizing priors on the slopes
############################################################

fit <- stan(file='linear_regression2.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)
# Much better fit with the stronger priors regularizing the non-identifiabilty

params = extract(fit)

# Much more reasonable slopes
hist(sapply(1:M, function(m) mean(params$beta[,m])), main="",
     xlab="Inferred Slope Means", breaks=breaks(10, 25))

hist(sapply(1:M, function(m) mean(params$beta[,m]) / sd(params$beta[,m])),
     main="", xlab="Inferred Slope Coeff of Var", breaks=breaks(10, 25))

# But now a few of the slope posteriors are nowhere close to the true values
# Our prior is regularizing the stronger slopes too much!
hist(sapply(1:M, function(m) (beta_true[m] - mean(params$beta[,m])) / sd(params$beta[,m])),
     main="", xlab="Relative Error", breaks=breaks(10, 25))

# The aggregated predictive distribution still looks okay
y_ppc = params$y_ppc
dim(y_ppc) <- NULL

p1 <- hist(y_ppc, breaks=breaks(200, 25), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=breaks(200, 25), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

############################################################
# Linear regression with weakly regularizing priors on the slopes
############################################################

fit <- stan(file='linear_regression3.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)
# Huge autocorrelations due to the non-identifiabilty

params = extract(fit)

# Much more reasonable slopes
hist(sapply(1:M, function(m) mean(params$beta[,m])), main="",
     xlab="Inferred Slope Means", breaks=breaks(10, 25))

# Although uncertainties are huge
hist(sapply(1:M, function(m) mean(params$beta[,m]) / sd(params$beta[,m])),
     main="", xlab="Inferred Slope Coeff of Var", breaks=breaks(1.25, 25))

# The increased uncertainties admit better agreement with the true values
hist(sapply(1:M, function(m) (beta_true[m] - mean(params$beta[,m])) / sd(params$beta[,m])),
     main="", xlab="Relative Error", breaks=breaks(1, 25))

# The aggregated predictive distribution still looks better, too
y_ppc = params$y_ppc
dim(y_ppc) <- NULL

p1 <- hist(y_ppc, breaks=breaks(200, 25), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=(200, 25) main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

############################################################
# Linear regression with the Finnish horseshoe prior (Param 1)
############################################################

fit <- stan(file='linear_regression5.stan', data=input_data, seed=4938483,
            control=list(adapt_delta=0.95))

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Much more reasonable slopes
hist(sapply(1:M, function(m) mean(params$beta[,m])), main="",
     xlab="Inferred Slope Means", breaks=breaks(12, 100))

# And a much more concentrated posterior
hist(sapply(1:M, function(m) mean(params$beta[,m]) / sd(params$beta[,m])),
     main="", xlab="Inferred Slope Coeff of Var", breaks=breaks(40, 100))

# The increased uncertainties admit better agreement with the true values
hist(sapply(1:M, function(m) (beta_true[m] - mean(params$beta[,m])) / sd(params$beta[,m])),
     main="", xlab="Relative Error", breaks=breaks(6, 25))

# The aggregated predictive distribution still looks better, too
y_ppc = params$y_ppc
dim(y_ppc) <- NULL

p1 <- hist(y_ppc, breaks=breaks(200, 25), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=breaks(200, 25), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)

############################################################
# Linear regression with the Finnish horseshoe prior (Param 2)
############################################################

fit <- stan(file='linear_regression5.stan', data=input_data, seed=4938483,
            control=list(adapt_delta=0.9))

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Much more reasonable slopes
hist(sapply(1:M, function(m) mean(params$beta[,m])), main="",
     xlab="Inferred Slope Means", breaks=breaks(12, 100))

# And a much more concentrated posterior
hist(sapply(1:M, function(m) mean(params$beta[,m]) / sd(params$beta[,m])),
     main="", xlab="Inferred Slope Coeff of Var", breaks=breaks(40, 100))

# The increased uncertainties admit better agreement with the true values
hist(sapply(1:M, function(m) (beta_true[m] - mean(params$beta[,m])) / sd(params$beta[,m])),
     main="", xlab="Relative Error", breaks=breaks(6, 25))

# The aggregated predictive distribution still looks better, too
y_ppc = params$y_ppc
dim(y_ppc) <- NULL

p1 <- hist(y_ppc, breaks=breaks(200, 25), main="", xlab="y")
p1$counts = p1$counts / sum(p1$counts)
p2 <- hist(input_data$y, breaks=breaks(200, 25), main="", xlab="y")
p2$counts = p2$counts / sum(p2$counts)
plot(p1, col=rgb(0, 0, 1, 0.25))
plot(p2, col=rgb(1, 0, 0, 0.25), add=T)
