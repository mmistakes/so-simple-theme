############################################################
# Initial setup
############################################################

library(rstan)
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
source('stan_utility.R')

############################################################
# Create data
############################################################

fit <- stan(file='generate_data.stan', iter=1,
            chains=1, seed=194838, algorithm="Fixed_param")

N <- 500
M <- 5
X <- extract(fit)$X[1,,]
y <- extract(fit)$y[1,]
stan_rdump(c("N", "M", "X", "y"), file="logistic_regression.data.R")

############################################################
# Fit initial Stan program
############################################################

input_data <- read_rdump('logistic_regression.data.R')
fit <- stan(file='logistic_regression1.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Plot marginal posteriors
par(mfrow=c(3, 2))

hist(params$alpha, main="", xlab="alpha")
abline(v=1,col=2,lty=1)

hist(params$beta[,1], main="", xlab="beta[1]")
abline(v=2.5,col=2,lty=1)

hist(params$beta[,2], main="", xlab="beta[2]")
abline(v=-1.5,col=2,lty=1)

hist(params$beta[,3], main="", xlab="beta[3]")
abline(v=1,col=2,lty=1)

hist(params$beta[,4], main="", xlab="beta[4]")
abline(v=-0.5,col=2,lty=1)

hist(params$beta[,5], main="", xlab="beta[5]")
abline(v=-3,col=2,lty=1)

# Visual posterior predictive check
hist(params$p_hat_ppc, main="", xlab="Successes / Trials")
abline(v=sum(input_data$y) / length(input_data$y), col=2, lty=1)

############################################################
# Fit with vectorized Stan program
############################################################

fit <- stan(file='logistic_regression2.stan', data=input_data, seed=4938483)

# Check diagnostics
print(fit)
check_treedepth(fit)
check_energy(fit)
check_div(fit)

params = extract(fit)

# Plot marginal posteriors
par(mfrow=c(3, 2))

hist(params$alpha, main="", xlab="alpha")
abline(v=1,col=2,lty=1)

hist(params$beta[,1], main="", xlab="beta[1]")
abline(v=2.5,col=2,lty=1)

hist(params$beta[,2], main="", xlab="beta[2]")
abline(v=-1.5,col=2,lty=1)

hist(params$beta[,3], main="", xlab="beta[3]")
abline(v=1,col=2,lty=1)

hist(params$beta[,4], main="", xlab="beta[4]")
abline(v=-0.5,col=2,lty=1)

hist(params$beta[,5], main="", xlab="beta[5]")
abline(v=-3,col=2,lty=1)

# Visual posterior predictive check
hist(params$p_hat_ppc, main="", xlab="Successes / Trials")
abline(v=sum(input_data$y) / length(input_data$y), col=2, lty=1)
